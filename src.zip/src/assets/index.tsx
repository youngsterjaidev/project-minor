import BearSVG from "./illustrations/BearSVG.svg";
import Dog from "./images/Dog.jpg";
import Bird from "./images/Bird.png";

export const Illustrations = {
  BearSVG,
  Dog,
  Bird
};
